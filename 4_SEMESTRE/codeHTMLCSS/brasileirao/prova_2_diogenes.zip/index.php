

<?php require_once('head.php')?>
<body class="hind-madurai-semibold">
  <h1 class="display-1 title">Brasileirão Série A</h1>
  <ul class="legenda__ul">
    <li><p>Libertadores </p> <i class="bi bi-circle-fill liberta-lg"></i></li>
    <li><p>Pré-libertadores </p> <i class="bi bi-circle-fill pre-liberta-lg"></i></li>
    <li><p>Sulamericana </p> <i class="bi bi-circle-fill sula-lg"></i></li>
    <li><p>Rebaixamento</p> <i class="bi bi-circle-fill degola-lg"></i></li>
  </ul>
  <table id="table" class="table table-striped shadow table-hover">
    <thead id="table-head">
    </thead>
    <tbody id="table-body">
    </tbody>
  </table>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="index.js"></script>
</html>