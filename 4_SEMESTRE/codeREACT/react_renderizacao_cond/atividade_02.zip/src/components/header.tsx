function Header(): JSX.Element {
    return (
        <header>
            <h1>Atividade 02</h1>
        </header>
    )
}

export default Header
