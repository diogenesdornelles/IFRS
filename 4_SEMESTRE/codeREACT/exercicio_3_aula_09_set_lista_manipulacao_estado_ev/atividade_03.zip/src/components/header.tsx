function Header(): JSX.Element {
    return (
        <header>
            <h1>Atividade 03</h1>
        </header>
    )
}

export default Header
