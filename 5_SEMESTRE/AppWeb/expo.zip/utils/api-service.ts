import axios, { AxiosInstance, AxiosError } from "axios";

export enum URLs {
    PROD = "https://api.escuelajs.co/api/v1/products",
    CAT = "https://api.escuelajs.co/api/v1/categories"
}


class ApiService<T> {
  private axiosInstance: AxiosInstance;
  public baseURL: URLs;
  constructor(baseURLprod: URLs) {
    this.baseURL = baseURLprod
    this.axiosInstance = axios.create({
      baseURL: this.baseURL,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  public async executeRequest(): Promise<T | void> {
    try {
      return await this.axiosInstance.get("/");
      }
    catch (error) {
      this.handleError(error as AxiosError);
    }
  }

  private handleError(error: AxiosError): void {
    if (error.response) {
      console.error(`Error: ${error.response.status} - ${error.response.data}`);
    } else if (error.request) {
      console.error("Error: No response received from server.");
    } else {
      console.error(`Error: ${error.message}`);
    }
  }
}

export default ApiService;