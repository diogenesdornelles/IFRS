function Footer(): JSX.Element {
    return (
        <footer>
            <p>© 2024 Atividade 02. Todos os direitos reservados.</p>
        </footer>
    )
}

export default Footer