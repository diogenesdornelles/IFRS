# Consumindo API com EXPO

Faça um aplicativo com expo que, usando https://fakeapi.platzi.com/en/about/introduction/, contenha:

1. Liste todas as categorias (coloque botões para carregar seus produtos).
2. Atualize o FlatList com os produtos da categoria escolhida;
3. Defina estilos para as categorias e produtos