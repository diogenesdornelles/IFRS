import TUser from '../types/user'

let users: TUser[] = [
  {
    username: 'usuario',
    password: 'senha',
  },
]

export default users;
