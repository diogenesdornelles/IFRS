type TUser = { username: string; password: string }

export default TUser;
