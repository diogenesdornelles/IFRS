import Categories from "./categories/categories";

export default function Index() {

  return (
    <Categories />
  );
}
