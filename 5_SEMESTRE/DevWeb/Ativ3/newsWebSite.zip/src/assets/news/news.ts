export interface New {
    id: number,
    titulo: string,
    noticia: string,
    link: string
}

const news: New[] = [
    {
        id: 0,
        titulo: "Título 1",
        noticia: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro mollitia necessitatibus laboriosam minus id voluptate, quod voluptatibus nulla facere suscipit ab itaque eius iure expedita fugiat quas cum ducimus maxime...",
        link: "#"
    },
    {
        id: 1,
        titulo: "Título 2",
        noticia: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro mollitia necessitatibus laboriosam minus id voluptate, quod voluptatibus nulla facere suscipit ab itaque eius iure expedita fugiat quas cum ducimus maxime...",
        link: "#"
    },
    {
        id: 2,
        titulo: "Título 2",
        noticia: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro mollitia necessitatibus laboriosam minus id voluptate, quod voluptatibus nulla facere suscipit ab itaque eius iure expedita fugiat quas cum ducimus maxime...",
        link: "#"
    }
]


export default news